JAROO'S COMPANY UI — 회사 PC 설치 패키지
기준일: 2026-11-23 (KST)
출처: https://github.com/jangjaru/Jaroo-UI-Release
상태: Neo-Brutalist v1.0 테스트 배포 / 실제 로그인 Chrome 최종 시각 검수 전

[포함된 최신 파일]
ChatGPT Tampermonkey:
- chatgpt/clock.user.js       v3.8.1
- chatgpt/status.user.js      v6.7.0
- chatgpt/mapper.user.js      v1.3.2
ChatGPT Stylus:
- chatgpt/theme.user.css      v8.0.1
Google Calendar Tampermonkey:
- calendar/companion.user.js  v1.3.7
Google Calendar Stylus:
- calendar/theme.user.css     v1.2.2

[교체 순서 - 중복 실행 방지]
1) 회사 PC의 기존 Tampermonkey/Stylus 설정을 먼저 각각 내보내 백업한다.
   기존 개인 프로필(생년월일/퇴직예정일/날씨 위치 등)이 있다면 반드시 별도 보존한다.
2) 기존 ChatGPT Clock / Status / Mapper 사용자 스크립트와 기존 ChatGPT Stylus
   스타일은 우선 '비활성화'한다. 개인 전용 프로필 스크립트는 지우지 않는다.
3) INSTALL_LINKS.html을 열어 ChatGPT 항목 4개를 순서대로 설치한다.
   Tampermonkey는 .user.js, Stylus는 .user.css 링크에서 설치한다.
   수동으로 파일을 편집해 설치할 때는 기존 버전의 중복 활성화를 피한다.
4) Google Calendar를 회사 PC에도 맞출 때만 Calendar 항목 2개를 설치/업데이트한다.
   Google Calendar용은 Neo 디자인 전환 대상이 아니며 기존 버전 그대로다.
5) 기존 확장프로그램 항목과 새 항목 중 동일 기능은 활성 항목이 하나만 남게 한다.
   ChatGPT를 새로고침하고 실제 로그인 상태에서 메뉴, 본문, 입력창을 확인한다.
6) Life Clock의 시간/인생 지표, RUN/DONE/ALL, 제목 역할 기호, 프로젝트 구분,
   좁은 사이드바, 긴 제목, 코드/표, Work 화면을 실제 검증한다.
7) 문제가 없을 때만 구버전 스크립트/스타일을 삭제할 수 있다.
   잘못되면 백업에서 복구한다.

[중요]
- 이 배포 ZIP에는 개인 전용 로컬 프로필이 들어있지 않다. 다른 PC에서
  Life Clock의 개인 지표가 보이지 않으면 로컬 전용 프로필을 안전하게 이관해야 한다.
- ChatGPT 앱의 자체 모양/액센트/배경/전경/폰트 크기 설정은
  Tampermonkey/Stylus 설치로 PC 사이에 자동 동기화되지 않을 수 있다.
- UserCSS의 @name에는 하위호환 업데이트 식별을 위해 'Dracula Neon'이 남아 있다.
  내부 코드는 Neo-Brutalist 8.0.1이므로 이름만 보고 구버전이라고 판단하지 않는다.
- Neo v1.0은 로컬 Chromium 테스트를 통과했지만, 회사 PC 실제 화면 검수는 별도다.
