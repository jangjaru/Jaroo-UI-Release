JAROO'S COMPANY UI · DRACULA NEON 마지막 버전 복구
제작 기준: 2026-11-22 · 복구 패키지 제작: 2026-11-23
원본 고정 Git 커밋: af603c9f929d6e51d71a232b57701116674318c6
복구 브랜치: dracula-v7.3.0-frozen-recovery-20261123

1. 패키지 구성
original/ : Dracula Neon 전환 직전 공개 코드 그대로 (총 6개)
frozen/   : 위 코드의 @updateURL, @downloadURL만 복구 전용 브랜치로 고정한 설치용 버전 (총 6개)
INSTALL_LINKS.html : frozen 6개 버전별 설치 주소
SHA256_original.json : 전환 직전 원본 SHA-256 목록

ChatGPT:
  CSS 7.3.0       original/chatgpt/theme.user.css
  Life Clock 3.7.3 original/chatgpt/clock.user.js
  RUN/DONE 6.5.3   original/chatgpt/status.user.js
  Mapper 1.3.2     original/chatgpt/mapper.user.js
Calendar:
  Companion 1.3.7 original/calendar/companion.user.js
  CSS 1.2.2       original/calendar/theme.user.css

2. 복구 절차 — 반드시 백업 우선
[백업]
A. 회사 컴퓨터의 Tampermonkey 대시보드에서 기존 스크립트 전체를 내보내 안전하게 보관.
B. Stylus에서도 내보내기로 현재 스타일 전체를 보관.
C. Life Clock 개인 전용 프로필 스크립트와 입력값은 별도로 보관. 이 ZIP에는 포함되지 않음.

[설치]
D. ChatGPT에서 현재 Neo CSS, Neo Clock, Neo Status를 각각 비활성화.
   동일 기능의 스크립트가 2개 동시에 켜지지 않도록 주의.
E. Tampermonkey에 Clock 3.7.3 / Status 6.5.3 / Mapper 1.3.2를 설치하거나 교체.
F. Stylus에 ChatGPT Dracula Neon CSS 7.3.0 설치.
G. Google Calendar는 마지막 Dracula 세트에서도 기존 버전과 동일하므로 문제가 없으면 재설치할 필요 없음.
H. 설치 완료 후 모든 같은 기능의 Neo 항목은 비활성화 유지. 정상 검증 이후에만 삭제.

[테마 설정 복구]
I. ChatGPT 모양 설정도 Neo 설정(라이트/베이지/청록)을 Dracula로 직접 복원할 것.
   권장: 다크 모드, Dracula 프리셋, 배경 #282A36, 전경 #F8F8F2, 액센트 #FF79C6.
   단, 사이트 테마 설정이 CSS보다 우선할 수 있으므로 실제 화면을 확인.
J. 새로고침 후 글꼴·Life Clock 날짜와 숫자·RUN/DONE·ALL/ONLY·프로젝트 색상·채팅 목록·입력창 확인.

3. 주의
- 이전 원본의 자동 업데이트 URL은 현재 main 브랜치로 향하므로 그대로 설치하면 Neo 최신 버전으로 다시 업데이트될 수 있음.
- 'frozen/' 버전은 코드 내용은 동일하고 업데이트 메타데이터만 고정하여 이 문제를 방지한 복구 설치용 파일임.
- Tampermonkey/Stylus가 낮은 버전 설치를 거부하면 기존 Neo 항목을 백업한 다음 비활성화/삭제 후 새 항목으로 재설치. 개인 프로필은 삭제하지 말 것.
- 설치 링크의 frozen 파일은 공개 저장소의 별도 복구 브랜치에 고정되어 있음.
- 최신 main 브랜치 업데이트를 다시 적용하지 않으려면 자동 업데이트 대상 URL이 frozen 브랜치인지 확인.
- 공식 제품 업데이트나 ChatGPT 웹 DOM 구조 변화로 과거 버전 기능이 깨질 수 있음. 로컬 브라우저 검증 필요.
- 사용자 개인 날짜, 위치, 자격증명 등은 배포 파일에 포함하지 않음.
